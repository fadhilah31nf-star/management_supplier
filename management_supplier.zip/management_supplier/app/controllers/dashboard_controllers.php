<?php
class DashboardController
{
    private $model;

    public function __construct($db)
    {
        require_once __DIR__ . '/../models/dashboard_model.php';
        $this->model = new dashboard_model($db);
    }

    public function index()
    {
        $totalPesanan   = $this->model->getTotalPesanan();
        $totalDikirim   = $this->model->getTotalDikirim();
        $totalDiambil   = $this->model->getTotalDiambil();
        $totalBarang    = $this->model->getTotalBarang();
        $totalSupplier  = $this->model->getTotalSupplier();
        $totalReturn    = $this->model->getTotalReturn();
        $pesananTerbaru = $this->model->getPesananTerbaru();

        // Chart data default (per bulan)
        $chartSupplier = $this->model->getChartPesananPerSupplier();
        $chartTime     = $this->model->getChartPesananPerBulan();

        require_once __DIR__ . '/../views/dashboard_views.php';
    }

    // Ajax untuk filter waktu chart (minggu, bulan, tahun)
    public function filterChart($periode)
    {
        $data = $this->model->getChartPesananPerTime($periode);
        echo json_encode($data);
    }
}
