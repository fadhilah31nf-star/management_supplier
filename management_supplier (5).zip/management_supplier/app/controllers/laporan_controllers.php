<?php
require_once __DIR__ . '/../models/laporan.php';

class LaporanController {
    private $db;
    private $laporan;

    public function __construct($db) {
        $this->db = $db;
        $this->laporan = new Laporan($db);
    }

    public function transaksi() {
        $from     = $_GET['from'] ?? null;
        $to       = $_GET['to'] ?? null;
        $supplier = $_GET['supplier'] ?? null;
        $jenis    = $_GET['jenis'] ?? null;
        $barang   = $_GET['barang'] ?? null;

        $data    = $this->laporan->getTransaksiGabungan($from, $to, $supplier, $jenis, $barang);
        $filters = $this->laporan->getFilterOptions();

        include __DIR__ . '/../views/laporan_transaksi_views.php';
    }

    public function stok() {
        $data = $this->laporan->getStokBarang();
        include __DIR__ . '/../views/laporan_stok_views.php';
    }
}
