<?php
class LogStokController {
    private $model;

    public function __construct($db) {
        require_once __DIR__ . '/../models/logstok.php';
        $this->model = new LogStok($db);
    }

    public function index() {
        $data = $this->model->getAllLog();
        require_once __DIR__ . '/../views/logstok_views.php';
    }
}
