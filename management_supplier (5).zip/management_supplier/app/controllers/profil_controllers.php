<?php
require_once __DIR__ . '/../models/profil.php';

class ProfilController {

    public function index() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['admin'])) {
            header("Location: index.php?controller=login&action=index");
            exit;
        }

        $profil = new Profil();
        $id_admin = $_SESSION['admin']['id_admin'];
        $data = $profil->getAdminById($id_admin);

        include __DIR__ . '/../views/profil_views.php';
    }

    public function update() {
        if (session_status() === PHP_SESSION_NONE) session_start();

        if (!isset($_SESSION['admin'])) {
            header("Location: index.php?controller=login&action=index");
            exit;
        }

        $id_admin = $_SESSION['admin']['id_admin'];
        $email = $_POST['email'] ?? '';
        $oldPassword = $_POST['old_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';

        $profil = new Profil();
        $adminData = $profil->getAdminById($id_admin);

        $errors = [];

        // Cek email
        if ($email != $adminData['email']) {
            $profil->updateEmail($id_admin, $email);
            $_SESSION['admin']['email'] = $email;
        }

        // Cek password lama sebelum update
        if (!empty($newPassword)) {
            if ($oldPassword === $adminData['password']) {
                $profil->updatePassword($id_admin, $newPassword);
            } else {
                $errors[] = "Password lama salah!";
            }
        }

        // Redirect dengan pesan
        if (!empty($errors)) {
            header("Location: index.php?controller=profil&action=index&error=" . urlencode($errors[0]));
        } else {
            header("Location: index.php?controller=profil&action=index&success=1");
        }
        exit;
    }
}
?>
