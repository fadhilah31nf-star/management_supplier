<?php include __DIR__ . '/template/header.php'; ?>

<div class="container mt-4">
    <h3 class="mb-3">Laporan Transaksi Barang</h3>

    <!-- FILTER PANEL -->
    <div class="card shadow-sm mb-4 p-3">
        <div class="card-body">
            <form method="get" class="row gy-3 gx-4">
                <input type="hidden" name="controller" value="laporan">
                <input type="hidden" name="action" value="transaksi">

                <div class="col-md-3">
                    <label class="fw-bold mb-1">Dari Tanggal</label>
                    <input type="date" name="from" class="form-control" value="<?= $_GET['from'] ?? '' ?>">
                </div>

                <div class="col-md-3">
                    <label class="fw-bold mb-1">Sampai Tanggal</label>
                    <input type="date" name="to" class="form-control" value="<?= $_GET['to'] ?? '' ?>">
                </div>

                <div class="col-md-2">
                    <label class="fw-bold mb-1">Supplier</label>
                    <select name="supplier" class="form-select">
                        <option value="">Semua</option>
                        <?php foreach($filters['supplier'] as $s): ?>
                            <option value="<?= $s ?>" <?= ($s == ($_GET['supplier'] ?? '')) ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="fw-bold mb-1">Jenis</label>
                    <select name="jenis" class="form-select">
                        <option value="">Semua</option>
                        <?php foreach($filters['jenis'] as $j): ?>
                            <option value="<?= $j ?>" <?= ($j == ($_GET['jenis'] ?? '')) ? 'selected' : '' ?>><?= $j ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="fw-bold mb-1">Barang</label>
                    <select name="barang" class="form-select">
                        <option value="">Semua</option>
                        <?php foreach($filters['barang'] as $b): ?>
                            <option value="<?= $b ?>" <?= ($b == ($_GET['barang'] ?? '')) ? 'selected' : '' ?>><?= $b ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-12 text-end mt-2">
                    <button class="btn btn-primary px-4 me-2">🔍 Tampilkan</button>
                    <a href="?controller=laporan&action=transaksi" class="btn btn-secondary px-4">↺ Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- TOMBOL CETAK -->
    <button class="btn btn-success mb-3" onclick="window.print()">🖨 CETAK</button>

    <!-- TABEL -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark text-center">
            <tr>
                <th>Tanggal</th>
                <th>Supplier</th>
                <th>Barang</th>
                <th>Jenis</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($data as $d): ?>
            <tr>
                <td><?= $d['tanggal'] ?></td>
                <td><?= $d['nama_supplier'] ?></td>
                <td><?= $d['nama_barang'] ?></td>
                <td class="text-center">
                    <?php if ($d['jenis'] == 'Masuk'): ?>
                        <span class="badge bg-success">Masuk</span>
                    <?php elseif ($d['jenis'] == 'Keluar'): ?>
                        <span class="badge bg-danger">Keluar</span>
                    <?php else: ?>
                        <span class="badge bg-warning text-dark">Retur</span>
                    <?php endif; ?>
                </td>
                <td class="text-center"><?= $d['jumlah'] ?></td>
                <td><?= $d['keterangan'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<style>
@media print { 
    form, button, .card, nav { display:none !important; } 
    table { font-size: 14px; }
}


.card {
    border-radius: 10px;
}
.card label {
    font-size: 14px;
}
.container {
    margin-bottom: 60px;
}
</style>

<?php include __DIR__ . '/template/footer.php'; ?>
