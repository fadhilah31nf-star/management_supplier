<?php include __DIR__ . '/template/header.php'; ?>

<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$admin = $_SESSION['admin'] ?? null;
?>

<div class="container">
    <h2>Profil Admin</h2>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
    <?php elseif (isset($_GET['success'])): ?>
        <div class="alert alert-success">Profil berhasil diperbarui!</div>
    <?php endif; ?>

    <form action="index.php?controller=profil&action=update" method="POST">
        <!-- Email -->
        <div class="form-group mb-2">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($admin['email']) ?>" required>
        </div>

        <hr>
        <h4>Ganti Password</h4>
        <div class="form-group mb-2">
            <label>Password Lama</label>
            <input type="password" name="old_password" class="form-control">
        </div>
        <div class="form-group mb-2">
            <label>Password Baru</label>
            <input type="password" name="new_password" class="form-control">
        </div>

        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
    </form>
</div>

<?php include __DIR__ . '/template/footer.php'; ?>