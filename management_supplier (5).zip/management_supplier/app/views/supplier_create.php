<div class="card shadow mb-4">
    <div class="card-header">
        <h4 class="mb-0">Tambah Supplier</h4>
    </div>

    <div class="card-body">
        <form method="POST" action="?controller=supplier&action=create">

            <div class="row">

                <!-- =====================
                     KOLOM KIRI
                ====================== -->
                <div class="col-md-6">

                    <!-- Nama Supplier -->
                    <div class="form-group mb-3">
                        <label>Nama Supplier</label>
                        <input type="text" name="nama_supplier" class="form-control" required>
                    </div>

                    <!-- Nama Alias -->
                    <div class="form-group mb-3">
                        <label>Nama Alias</label>
                        <input type="text" name="nama_alias" class="form-control" required>
                    </div>

                    <!-- Alamat -->
                    <div class="form-group mb-3">
                        <label>Alamat</label>
                        <textarea name="alamat" class="form-control" required></textarea>
                    </div>

                </div>

                <!-- =====================
                     KOLOM KANAN
                ====================== -->
                <div class="col-md-6">

                    <!-- Telepon -->
                    <div class="form-group mb-3">
                        <label>No Telepon</label>
                        <input type="text" name="no_telp" class="form-control" required>
                    </div>

                    <!-- Tipe Supplier -->
                    <div class="form-group mb-3">
                        <label>Tipe Supplier</label>
                        <select name="tipe_supplier" class="form-control" required>
                            <option value="">-- Pilih Tipe --</option>
                            <option value="Mengirim">Mengirim</option>
                            <option value="Diambil">Diambil</option>
                            <option value="Datang_langsung">Datang Langsung</option>
                        </select>
                    </div>

                    <!-- Jadwal Pengiriman -->
                    <div class="form-group mb-3">
                        <label>Jadwal Pengiriman</label>
                        <input type="date" name="jadwal_pengiriman" class="form-control" required>
                    </div>

                </div>

            </div>

            <button type="submit" class="btn btn-success mt-2">Simpan</button>
        </form>
    </div>
</div>
