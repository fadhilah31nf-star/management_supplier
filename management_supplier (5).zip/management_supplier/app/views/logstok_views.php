<?php include __DIR__ . '/template/header.php'; ?>

<div class="container-fluid">
    <h2 class="mt-4 mb-4">Log Perubahan Stok</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <i class="fas fa-clipboard-list"></i>
            <span>Log Stok Barang</span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="logStokTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID Log</th>
                            <th>Barang</th>
                            <th>Perubahan</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data as $row) : ?>
                            <tr>
                                <td><?= $row['id_log'] ?></td>
                                <td><?= $row['nama_barang'] ?></td>
                                <td><?= $row['perubahan'] ?></td>
                                <td><?= $row['jumlah'] ?></td>
                                <td><?= $row['keterangan'] ?></td>
                                <td><?= $row['tanggal'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- DataTables JS -->
<script src="admin/js/jquery-3.6.0.min.js"></script>
<script src="admin/js/bootstrap.bundle.min.js"></script>
<script src="admin/js/plugins/dataTables/jquery.dataTables.min.js"></script>
<script src="admin/js/plugins/dataTables/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready(function() {
        $('#logStokTable').DataTable({
            "order": [[5, "desc"]], // urut berdasarkan tanggal DESC
            "columnDefs": [
                { "orderable": false, "targets": [] } // kolom yang tidak bisa diurutkan (kosong)
            ]
        });
    });
</script>

<?php include __DIR__ . '/template/footer.php'; ?>
