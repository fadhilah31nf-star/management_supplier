<?php include __DIR__ . '/template/header.php'; ?>

<div class="container mt-4">
    <h3>Laporan Stok Barang</h3>

    <button class="btn btn-success mb-3" onclick="window.print()">CETAK</button>

    <table class="table table-bordered table-striped">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Nama Barang</th>
                <th>Supplier</th>
                <th>Harga</th>
                <th>Stok</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($data as $d): ?>
            <tr>
                <td><?= $d['id_barang'] ?></td>
                <td><?= $d['nama_barang'] ?></td>
                <td><?= $d['nama_supplier'] ?></td>
                <td>Rp <?= number_format($d['harga'],0,',','.') ?></td>
                <td>
                    <?= $d['stok'] ?>
                    <?php if ($d['stok'] <= 5): ?>
                        <span class="badge bg-danger">Hampir Habis</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<style>
@media print { button, nav { display:none; } }
</style>

<?php include __DIR__ . '/template/footer.php'; ?>
