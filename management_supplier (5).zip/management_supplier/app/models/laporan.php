<?php
class Laporan {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getTransaksiGabungan($from = null, $to = null, $supplier = null, $jenis = null, $barang = null) {

        $where = [];
        if ($from && $to) $where[] = "tanggal BETWEEN '$from' AND '$to'";
        if ($supplier)    $where[] = "nama_supplier = '$supplier'";
        if ($jenis)       $where[] = "jenis = '$jenis'";
        if ($barang)      $where[] = "nama_barang = '$barang'";

        $where_sql = $where ? "WHERE " . implode(" AND ", $where) : "";

        $sql = "
            SELECT * FROM (
                SELECT 
                    p.tgl_pengiriman AS tanggal,
                    s.nama_supplier,
                    b.nama_barang,
                    dp.jumlah_barang AS jumlah,
                    'Masuk' AS jenis,
                    '' AS keterangan
                FROM detail_pengiriman dp
                JOIN pengiriman p ON p.id_pengiriman = dp.id_pengiriman
                JOIN barang b ON b.id_barang = dp.id_barang
                JOIN supplier s ON s.id_supplier = p.id_supplier

                UNION ALL

                SELECT 
                    ps.tgl_pesanan AS tanggal,
                    s.nama_supplier,
                    b.nama_barang,
                    dp.jumlah AS jumlah,
                    'Keluar' AS jenis,
                    ps.status AS keterangan
                FROM detail_pesanan dp
                JOIN pesanan ps ON ps.id_pesanan = dp.id_pesanan
                JOIN barang b ON b.id_barang = dp.id_barang
                JOIN supplier s ON s.id_supplier = ps.id_supplier

                UNION ALL

                SELECT 
                    r.tanggal_return AS tanggal,
                    s.nama_supplier,
                    b.nama_barang,
                    r.jumlah AS jumlah,
                    'Retur' AS jenis,
                    r.alasan AS keterangan
                FROM return_to r
                JOIN barang b ON b.id_barang = r.id_barang
                JOIN supplier s ON s.id_supplier = r.id_supplier
            ) AS laporan
            $where_sql
            ORDER BY tanggal DESC
        ";

        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Dropdown sumber data filter
    public function getFilterOptions() {
        return [
            'supplier' => $this->db->query("SELECT nama_supplier FROM supplier ORDER BY nama_supplier")->fetchAll(PDO::FETCH_COLUMN),
            'barang'   => $this->db->query("SELECT nama_barang FROM barang ORDER BY nama_barang")->fetchAll(PDO::FETCH_COLUMN),
            'jenis'    => ['Masuk', 'Keluar', 'Retur']
        ];
    }

    public function getStokBarang() {
        $sql = "
            SELECT b.*, s.nama_supplier
            FROM barang b
            JOIN supplier s ON s.id_supplier = b.id_supplier
            ORDER BY b.nama_barang ASC
        ";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
