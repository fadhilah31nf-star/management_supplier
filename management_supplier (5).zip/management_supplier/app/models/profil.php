<?php
require_once __DIR__ . '/../config/database.php';

class Profil {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    // Ambil data admin berdasarkan id
    public function getAdminById($id_admin) {
        $stmt = $this->conn->prepare("SELECT id_admin, email, password FROM admin WHERE id_admin = :id");
        $stmt->bindParam(':id', $id_admin);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Update profil (email)
    public function updateEmail($id_admin, $email) {
        $stmt = $this->conn->prepare("UPDATE admin SET email = :email WHERE id_admin = :id");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':id', $id_admin);
        return $stmt->execute();
    }

    // Update password
    public function updatePassword($id_admin, $newPassword) {
        $stmt = $this->conn->prepare("UPDATE admin SET password = :password WHERE id_admin = :id");
        $stmt->bindParam(':password', $newPassword);
        $stmt->bindParam(':id', $id_admin);
        return $stmt->execute();
    }
}
?>
